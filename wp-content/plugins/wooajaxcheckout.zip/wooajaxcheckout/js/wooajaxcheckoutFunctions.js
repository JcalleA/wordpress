console.log('====================================');
console.log('ojjjkk');
console.log('====================================');

jQuery(document).ready(function ($) {

 
    $('#countrySelect').change(function (e) { 
      e.preventDefault();
      alert('ok')
      
      let city=$('#countrySelect').val();
      
      $.ajax({
        url:pro_checkout_var.url,
        type:"GET",
        dataType:"json",
        data:"action=" + pro_checkout_var.action + "&nonce=" + pro_checkout_var.nonce,
        method: 'GET',
        timeout: 3000,
        cache: false,
          success:function(response){
            alert(response)
          },
          error:function(status,error){
            console.log('====================================');
            console.log(error);
            console.log('====================================');
            console.error(status+': '+error)

          }
        },
        
        
      )
      
    });
    
    
  
})
